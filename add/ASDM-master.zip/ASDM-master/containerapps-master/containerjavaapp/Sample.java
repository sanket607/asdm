class Sample{ 
   public static void main(String[] args)  { 
   System.out.println("This is java application by using docker ");
   } 
   }